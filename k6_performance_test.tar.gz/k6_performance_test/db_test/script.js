import http from 'k6/http';
import {check} from 'k6';


const options = {
    vus : 1,
    iterations : 1
}

export default function(){
    const url = 'http://localhost:8000/db_test'
    const response = http.post(url);

    // const params = {
    //     headers : {'Authorization': 'Bearer token'},
    // }
    http.post(url)
    check(response, {
        'status is 200': (r) => r.status === 200,
    });
}