package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

const URI = "mongodb://localhost:27017"

type DbTest struct {
	Token string `json: "token"`
}

func DBConnection()(*mongo.Collection){
	connection := options.Client().ApplyURI(URI)
	client, err := mongo.Connect(context.TODO(), connection)
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Database Connected")
	err1 := client.Ping(context.TODO(), nil)
	if err1 != nil {
		log.Fatal("Mongodb is not available")
	}

	collection := client.Database("k6").Collection("db_test")
	return collection
}

func API()(*gin.Engine){
	r := gin.Default()
	return r
}

func main() {
	apiClient := API()
	apiClient.POST("/insert_tok", handleinsert)

}

func handleinsert(c *gin.Context) {
	mongo := DBConnection()
	// Declare Context type object for managing multiple API requests
	ctx, _ := context.WithTimeout(context.Background(), 15*time.Second)
	var temp DbTest
	_, err2 := mongo.InsertOne(ctx, &temp)
	if err2 != nil {
		log.Fatal(err2)
	}
	fmt.Println("Inserted succesfully")
	
	// // Parse the JSON request body
	// var requestBody map[string]interface{}
	// if err := c.ShouldBindJSON(&requestBody); err != nil {
	// 	c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
	// 	return
	// }

	// // Send the modified JSON as a response
	// c.JSON(http.StatusOK, requestBody)
}
