import http from 'k6/http';
import { check, sleep } from 'k6';


export const options = {
    vus: 1,
    iterations: 10,
}

export default function(){
    const url = 'http://localhost:8080/k6test';
    // Define the JSON request body
    const payload = JSON.stringify({
        message: 'Hello, world!',
    });

    const response = http.post(url);

    check(response, {
        'status is 200': (r) => r.status === 400,
    });
}
